import java.util.Scanner;

public class Task1 {
  public static void main(String[] args){

    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter file size (K)kilobytes, (M)megabytes, (G)gigabytes: ");
    String input = scanner.nextLine();
    System.out.println(convertToBytes(input) + " bytes");
  }

  public static double convertToBytes(String input) {
    String strNumber = input.substring(0, input.length() - 1);
    char unit = input.charAt(input.length() - 1);

    double number = Double.parseDouble(strNumber);
    switch (unit) {
      case 'G':
        number *= 1024;
      case 'M':
        number *= 1024;
      case 'K':
        number *= 1024;
        break;
      default:
        number = -1;
    }

    return number;
  }
}
