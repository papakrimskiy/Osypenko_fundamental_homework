import orders.ServiceOrder;
import java.util.Date;

public class Main {

  public static void main(String[] args) {
    ServiceOrder order = new ServiceOrder(19, "phone", new Date(2025, 1, 30), "Electronics");
  }
}