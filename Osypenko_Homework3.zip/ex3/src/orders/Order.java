package orders;

import java.util.ArrayList;
import java.util.Date;

public abstract class Order {
  private double price;
  private String name;
  private ArrayList<String> items;
  private Date orderDate;

  public Order(double price, String name, Date orderDate) {
    this.price = price;
    this.name = name;
    this.items = new ArrayList<>();
    this.orderDate = orderDate;
  }

  protected double getPrice() {
    return price;
  }

  protected String getName() {
    return name;
  }

  protected ArrayList<String> getItems() {
    return items;
  }

  protected Date getOrderDate() {
    return orderDate;
  }

  public String getOrder() {
    return name + '-' + price + '-' + orderDate;
  }

  public void addItem(String item, Number itemPrice) {
    items.add(item);
    this.price += itemPrice.doubleValue();
  }
}
