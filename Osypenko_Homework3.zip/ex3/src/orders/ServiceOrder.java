package orders;

import java.util.Date;

public class ServiceOrder extends Order {
  private String serviceType;

  public ServiceOrder(double price, String name, Date orderDate, String serviceType) {
    super(price, name, orderDate);
    this.serviceType = serviceType;
  }

  @Override
  public String getOrder() {
    return getName() + '-' + serviceType + '-' + getPrice() + '-' + getOrderDate();
  }
}