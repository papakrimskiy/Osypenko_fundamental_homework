package orders;

import java.util.Date;

public class ProductOrder extends Order {

  public ProductOrder(double price, String name, Date orderDate) {
    super(price, name, orderDate);
  }
}
